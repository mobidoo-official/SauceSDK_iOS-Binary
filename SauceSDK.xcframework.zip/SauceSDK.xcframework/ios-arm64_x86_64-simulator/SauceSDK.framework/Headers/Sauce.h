//
//  Sauce.h
//  Sauce
//
//  Created by DevPlayNew on 6/11/25.
//

#import <Foundation/Foundation.h>

//! Project version number for Sauce.
FOUNDATION_EXPORT double SauceVersionNumber;

//! Project version string for Sauce.
FOUNDATION_EXPORT const unsigned char SauceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Sauce/PublicHeader.h>


